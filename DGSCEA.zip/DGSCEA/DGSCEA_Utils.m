classdef DGSCEA_Utils
% Utility methods used by DGSCEA.

    methods(Static)
        function [E,UpdateSet] = SelectParents(B,activeDir,N)
            % Select globally with 20% probability and from the neighborhood otherwise.
            UpdateSet = cell(1,N);
            for i = 1:N
                if rand < 0.2
                    P = randperm(N);
                else
                    P = B(i,randperm(size(B,2)));
                end
                if length(P) == 1
                    P = [P,P];
                end
                UpdateSet{i} = P;
            end
            E = zeros(length(activeDir),2);
            for i = 1:length(activeDir)
                P = UpdateSet{activeDir(i)};
                E(i,:) = P(1:2);
            end
        end

        function Offspring = TournamentGA(Problem,Population,nOffspring,Fitness)
            if nOffspring <= 0 || isempty(Population)
                Offspring = [];
            else
                Fitness = reshape(Fitness,1,[]);
                if length(Fitness) ~= length(Population)
                    error('DGSCEA:InvalidTournamentFitness', ...
                        'Fitness length %d does not match population size %d.', ...
                        length(Fitness),length(Population));
                end
                matingPool = TournamentSelection(2,2*nOffspring,Fitness);
                Offspring = OperatorGAhalf(Problem,Population(matingPool));
            end
        end

        function NewP2 = UpdateP2Stage1(P2,O2,activeDir,UpdateSet,W,nr)
            % Stage 1: update P2 according to the aggregation value.
            Z = min([P2.objs;O2.objs],[],1);
            NewP2 = P2;
            bestG = DGSCEA_Utils.Aggregation(P2,W,Z,[],0,0);
            for i = 1:length(O2)
                direction = activeDir(i);
                P = UpdateSet{direction};
                child = O2(i);
                children = child(ones(1,length(P)));
                gNew = DGSCEA_Utils.Aggregation(children,W(P,:),Z,[],0,0);
                gOld = DGSCEA_Utils.Aggregation(P2(P),W(P,:),Z,[],0,0);
                targets = P(find(gNew <= gOld,nr));
                for k = 1:length(targets)
                    j = targets(k);
                    g = DGSCEA_Utils.Aggregation(child,W(j,:),Z,[],0,0);
                    if g <= bestG(j)
                        NewP2(j) = child;
                        bestG(j) = g;
                    end
                end
            end
        end

        function NewP2 = UpdateP2Cooperative(P2,O2,O3,activeDir, ...
                UpdateSet,W,B,nr,K2,useLocal,theta,epsilonP)
            % Select a candidate from the top-K2 solutions for each direction.
            Q = [O2,O3];
            Z = min([P2.objs;Q.objs],[],1);
            if useLocal
                localRate = DGSCEA_Utils.LocalRate(P2,B);
            else
                localRate = [];
            end

            NewP2 = P2;
            bestG = DGSCEA_Utils.Aggregation(P2,W,Z,localRate,theta,epsilonP);
            for i = 1:length(P2)
                if useLocal
                    rate = localRate(i);
                else
                    rate = [];
                end
                gQ = DGSCEA_Utils.Aggregation(Q,W(i,:),Z,rate,theta,epsilonP);
                [~,rank] = sort(gQ);
                top = min(K2,length(rank));
                child = Q(rank(randi(top)));

                own = find(activeDir == i,1);
                if ~isempty(own)
                    gChild = DGSCEA_Utils.Aggregation(child,W(i,:),Z,rate,theta,epsilonP);
                    gOwn = DGSCEA_Utils.Aggregation(O2(own),W(i,:),Z,rate,theta,epsilonP);
                    if gOwn < gChild
                        child = O2(own);
                    end
                end

                P = UpdateSet{i};
                children = child(ones(1,length(P)));
                if useLocal
                    rates = localRate(P);
                else
                    rates = [];
                end
                gNew = DGSCEA_Utils.Aggregation(children,W(P,:),Z,rates,theta,epsilonP);
                gOld = DGSCEA_Utils.Aggregation(P2(P),W(P,:),Z,rates,theta,epsilonP);
                targets = P(find(gNew <= gOld,nr));
                for k = 1:length(targets)
                    j = targets(k);
                    if useLocal
                        rate = localRate(j);
                    else
                        rate = [];
                    end
                    g = DGSCEA_Utils.Aggregation(child,W(j,:),Z,rate,theta,epsilonP);
                    if g <= bestG(j)
                        NewP2(j) = child;
                        bestG(j) = g;
                    end
                end
            end
        end

        function g = Aggregation(Population,Weight,Z,localRate,theta,epsilonP)
            if isempty(Population)
                g = zeros(0,1);
                return;
            end
            if size(Weight,1) == 1
                Weight = repmat(Weight,length(Population),1);
            end
            Weight = max(Weight,1e-12);
            g = max(abs(Population.objs-repmat(Z,length(Population),1))./Weight,[],2);
            if ~isempty(localRate)
                if isscalar(localRate)
                    localRate = repmat(localRate,length(Population),1);
                else
                    localRate = localRate(:);
                end
                CV = sum(max(0,Population.cons),2);
                g = g + theta.*max(epsilonP,1-localRate).*CV;
            end
        end

        function rate = LocalRate(P2,B)
            CV = sum(max(0,P2.cons),2);
            rate = zeros(length(P2),1);
            for i = 1:length(P2)
                rate(i) = mean(CV(B(i,:)) <= 1e-6);
            end
        end

        function VAR = InitialVAR(Population)
            CV = sum(max(0,Population.cons),2);
            infeasible = CV > 0;
            if any(infeasible)
                VAR = median(CV(infeasible));
            else
                VAR = 0;
            end
        end

        function VAR = UpdateVAR(O3,stage2StartFE,Problem)
            if isempty(O3)
                VAR = 0;
                return;
            end
            CV = sum(max(0,O3.cons),2);
            infeasible = CV > 0;
            if any(infeasible)
                denominator = max(Problem.maxFE-stage2StartFE,1);
                tau = (Problem.FE-stage2StartFE)/denominator;
                tau = min(1,max(0,tau));
                K = (1-tanh(4*(2*tau-1)))/2;
                VAR = K*median(CV(infeasible));
            else
                VAR = 0;
            end
        end
    end
end
