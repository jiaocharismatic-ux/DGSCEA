function [return_pop,return_Fitness] = DGSCEA_EnvironmentalSelection_VAR(Population,N,VAR)

    candidateCount = length(Population);
    if candidateCount < N
        error('DGSCEA:CandidatePoolTooSmall', ...
            'P3 cannot be completed to N=%d from only %d candidates.', ...
            N,candidateCount);
    end

    input_cons = Population.cons;
    input_cons(input_cons<0) = 0;
    input_cons = sum(input_cons,2);

    findex = find(input_cons<=VAR);
    fPopulation = Population(findex);
    selectedIndex = zeros(1,0);

    if isempty(fPopulation)
        fPopulation = [];
    elseif length(fPopulation) <= N
        cons = fPopulation.cons;
        cons(cons<0)=0;
        cons = sum(cons,2);
        fFitness = DGSCEA_CalFitness([fPopulation.objs,cons]);

        % Sort the population
        [~,rank] = sort(fFitness);
        fPopulation = fPopulation(rank);
        selectedIndex = reshape(findex(rank),1,[]);
    elseif length(fPopulation) > N
        cons = fPopulation.cons;
        cons(cons<0)=0;
        cons = sum(cons,2);
        fFitness = DGSCEA_CalFitness([fPopulation.objs,cons]);
        Next = fFitness < 1;
        if sum(Next) <= N
            [~,Rank] = sort(fFitness);
            Next(Rank(1:N )) = true;
        elseif sum(Next) > N
            Del  = Truncation(fPopulation(Next).objs, sum(Next)-N );
            Temp = find(Next);
            Next(Temp(Del)) = false;
        end

        selectedIndex = findex(Next);
        fPopulation = fPopulation(Next);
        fFitness   = fFitness(Next);
        % Sort the population
        [~,rank] = sort(fFitness);
        fPopulation = fPopulation(rank);
        selectedIndex = reshape(selectedIndex(rank),1,[]);

    end

    %% Complete P3 with candidates that were not selected above
    if length(fPopulation) < N
        selectedMask = false(1,candidateCount);
        selectedMask(selectedIndex) = true;
        availableIndex = find(~selectedMask);
        fillCount = N-length(fPopulation);
        if length(availableIndex) < fillCount
            error('DGSCEA:InsufficientUnselectedCandidates', ...
                'P3 needs %d additions, but only %d unselected candidates remain.', ...
                fillCount,length(availableIndex));
        end

        % Evaluate the remaining candidates in the full candidate pool.
        % Constraint violation is the primary key; fitness and index break ties.
        poolFitness = DGSCEA_CalFitness( ...
            [Population.objs,input_cons]);
        cvKey = input_cons(availableIndex);
        fitnessKey = poolFitness(availableIndex);
        indexKey = availableIndex(:);
        [~,order] = sortrows( ...
            [cvKey(:),fitnessKey(:),indexKey],[1,2,3]);
        fillIndex = reshape(availableIndex(order(1:fillCount)),1,[]);

        fPopulation = [fPopulation,Population(fillIndex)];
    end

    if length(fPopulation) ~= N
        error('DGSCEA:InvalidP3Size', ...
            'P3 has %d individuals after selection; expected N=%d.', ...
            length(fPopulation),N);
    end

    %% Use one comparison context for all final P3 mating fitness values
    return_pop = fPopulation;
    return_Fitness = DGSCEA_P3Fitness(return_pop);
end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end
