function Fitness = DGSCEA_P3Fitness(Population)
% Calculate one consistent mating-fitness vector for the current P3.

    CV = sum(max(0,Population.cons),2);
    Fitness = DGSCEA_CalFitness([Population.objs,CV]);
end
