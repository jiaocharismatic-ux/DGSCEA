classdef DGSCEA < ALGORITHM
% <multi> <real> <constrained>

    methods
        function main(Algorithm,Problem)
            %% Generate weight vectors and the initial decomposition population
            [RW,Problem.N] = UniformPoint(Problem.N,Problem.M);
            N   = Problem.N;
            W   = RW(end:-1:1,:);
            T   = min(N,max(2,ceil(N/10)));
            nr  = max(1,ceil(N/100));
            K2  = 5;

            Distance = pdist2(W,W);
            [~,B] = sort(Distance,2);
            B = B(:,1:T);

            P2         = Problem.Initialization();
            Arch       = DGSCEA_ArchiveUpdate(P2,N);
            Population = Arch;

            %% Parameters
            stage       = 1;
            stage2Ready = false;
            currentVAR  = 0;
            dirQueue    = randperm(N);

            L           = 10;
            deltaZ      = 1e-3;
            epsilonZ    = 1e-3;
            stableNeed  = 10;
            stableCount = 0;
            zHistory    = min(P2.objs,[],1);

            theta       = 15;
            epsilonP    = 1e-3;
            switchThresholds = struct( ...
                'relativeGainTolerance',0.005, ...
                'gainEpsilon',1e-12, ...
                'windowLength',50, ...
                'rateThreshold',0.05, ...
                'gainThreshold',0.001, ...
                'lowRatioThreshold',0.90, ...
                'stage1CapRatio',0.35, ...
                'stage2CapRatio',0.60);
            rateHistory = zeros(0,1);
            gainHistory = zeros(0,1);
            stage2StartFE  = NaN;
            stage1NaturalConditionHit = false;
            stage1CapConditionHit = false;

            %% Optimization
            while Algorithm.NotTerminated(Population)
                if stage == 1
                    %% P2 searches the UPF with GA
                    activeDir = 1:N;
                    [E,UpdateSet] = DGSCEA_Utils.SelectParents(B,activeDir,N);
                    O2 = OperatorGAhalf(Problem,[P2(E(:,1)),P2(E(:,2))]);
                    P2 = DGSCEA_Utils.UpdateP2Stage1(P2,O2,activeDir,UpdateSet,W,nr);

                    Arch       = DGSCEA_ArchiveUpdate([Arch,P2],N);
                    Population = Arch;

                    %% Detect stabilization of the ideal point
                    zNow     = min(P2.objs,[],1);
                    zHistory = [zHistory;zNow];
                    if size(zHistory,1) > L
                        zOld = zHistory(end-L,:);
                        rate = max(abs(zNow-zOld)./max(abs(zOld),deltaZ));
                        if rate < epsilonZ
                            stableCount = stableCount + 1;
                        else
                            stableCount = 0;
                        end
                    end
                    if size(zHistory,1) > L+1
                        zHistory(1,:) = [];
                    end
                    stage1NaturalConditionHit = stableCount >= stableNeed;
                    stage1CapConditionHit = Problem.FE >= ...
                        switchThresholds.stage1CapRatio*Problem.maxFE;
                    if stage1NaturalConditionHit || stage1CapConditionHit
                        stage         = 2; 
                    end
                    continue;
                end

                %% Initialize P1 and P3 once at the beginning of stage 2
                if ~stage2Ready
                    CV2 = sum(max(0,P2.cons),2);
                    eta = mean(CV2 == 0);
                    if eta >= 0.5
                        P1       = P2;
                        P3       = P2;
                        Fitness1 = DGSCEA_CalFitness(P1.objs,P1.cons);
                        Fitness3 = DGSCEA_P3Fitness(P3);
                        currentVAR = DGSCEA_Utils.InitialVAR(P3);
                    else
                        R    = Problem.Initialization();
                        currentVAR = DGSCEA_Utils.InitialVAR(R);
                        [P1,Fitness1] = DGSCEA_EnvironmentalSelection([R,P2,Arch],N,true);
                        [P3,Fitness3] = DGSCEA_EnvironmentalSelection_VAR([R,P2,Arch],N,currentVAR);
                    end

                    if eta >= 0.65
                        n2 = ceil(3*N/5);
                    elseif eta >= 0.5
                        n2 = ceil(N/2);
                    else
                        n2 = ceil(2*N/5);
                    end
                    n1 = N;
                    n3 = N-n2;

                    stage2StartFE = Problem.FE;
                    rateHistory = zeros(0,1);
                    gainHistory = zeros(0,1);
                    stage2Ready = true;
                    if Problem.FE >= Problem.maxFE
                        Arch       = DGSCEA_ArchiveUpdate([Arch,P1,P2,P3],N);
                        Population = Arch;
                        continue;
                    end
                end

               %% Adjust the offspring allocation for stage 3
                if stage == 3
                    n2 = ceil(N/2);
                    n3 = N-n2;
                end

                %% Assign P2 resources and generate three offspring sets
                activeDir = dirQueue(1:n2);
                dirQueue  = [dirQueue(n2+1:end),activeDir];
                [E,UpdateSet] = DGSCEA_Utils.SelectParents(B,activeDir,N);

                O1 = DGSCEA_Utils.TournamentGA(Problem,P1,n1,Fitness1);
                if stage == 2
                    O2 = OperatorGAhalf(Problem,[P2(E(:,1)),P2(E(:,2))]);
                else
                    O2 = OperatorDE(Problem,P2(activeDir),P2(E(:,1)),P2(E(:,2)));
                end
                O3 = DGSCEA_Utils.TournamentGA(Problem,P3,n3,Fitness3);

                %% Update the boundary from the newly generated P3 offspring
                currentVAR = DGSCEA_Utils.UpdateVAR( ...
                    O3,stage2StartFE,Problem);

                %% Synchronously update the three populations
                OldP1 = P1;
                OldP2 = P2;
                OldP3 = P3;

                if stage == 2
                    progressZ = min([OldP2.objs;O2.objs;O3.objs],[],1);
                    oldDirectionG = DGSCEA_Utils.Aggregation( ...
                        OldP2,W,progressZ,[],0,0);
                    [P1,Fitness1] = DGSCEA_EnvironmentalSelection([OldP1,O1,O2,O3],N,true);
                    P2 = DGSCEA_Utils.UpdateP2Cooperative(OldP2,O2,O3,activeDir, ...
                        UpdateSet,W,B,nr,K2,false,theta,epsilonP);
                    newDirectionG = DGSCEA_Utils.Aggregation( ...
                        P2,W,progressZ,[],0,0);
                    [P3,Fitness3] = DGSCEA_EnvironmentalSelection_VAR([OldP3,O1,O2,O3],N,currentVAR);
                else
                    Q1 = [O2,O3,OldP3,Arch];
                    CV1 = sum(max(0,Q1.cons),2);
                    C1 = Q1(CV1 == 0);
                    [P1,Fitness1] = DGSCEA_EnvironmentalSelection([OldP1,O1,C1],N,true);

                    P2 = DGSCEA_Utils.UpdateP2Cooperative(OldP2,O2,O3,activeDir, ...
                        UpdateSet,W,B,nr,K2,true,theta,epsilonP);

                    Q3 = [OldP1,O1,O2];
                    CV3 = sum(max(0,Q3.cons),2);
                    C3 = Q3(CV3 <= currentVAR);
                    [P3,Fitness3] = DGSCEA_EnvironmentalSelection_VAR([OldP3,O3,C3],N,currentVAR);
                end

                Arch = DGSCEA_ArchiveUpdate([Arch,P1,P2,P3],N);
                Population = Arch;

                %% Detect low directional improvement of P2 in stage 2
                if stage == 2
                    relativeGain = (oldDirectionG-newDirectionG)./ ...
                        max(abs(oldDirectionG),switchThresholds.gainEpsilon);
                    improved = relativeGain > switchThresholds.relativeGainTolerance;
                    improvementRate = mean(improved);
                    effectiveGain = zeros(size(relativeGain));
                    effectiveGain(improved) = relativeGain(improved);
                    averageGain = mean(effectiveGain);

                    rateHistory = [rateHistory;improvementRate];
                    gainHistory = [gainHistory;averageGain];

                    normalConditionHit = false;
                    meanImprovementRate = NaN;
                    meanAverageGain = NaN;
                    lowGenerationRatio = NaN;
                    p2WindowAvailable = length(rateHistory) >= ...
                        switchThresholds.windowLength;
                    if p2WindowAvailable
                        first = length(rateHistory)-switchThresholds.windowLength+1;
                        rateWindow = rateHistory(first:end);
                        gainWindow = gainHistory(first:end);
                        meanImprovementRate = mean(rateWindow);
                        meanAverageGain = mean(gainWindow);
                        lowGeneration = ...
                            rateWindow <= switchThresholds.rateThreshold & ...
                            gainWindow <= switchThresholds.gainThreshold;
                        lowGenerationRatio = mean(lowGeneration);
                        normalConditionHit = ...
                            meanImprovementRate <= switchThresholds.rateThreshold && ...
                            meanAverageGain <= switchThresholds.gainThreshold && ...
                            lowGenerationRatio >= switchThresholds.lowRatioThreshold;
                    end
                    stage2CapConditionHit = Problem.FE >= ...
                        switchThresholds.stage2CapRatio*Problem.maxFE && ...
                        p2WindowAvailable;
                    if normalConditionHit || stage2CapConditionHit  
                        stage = 3;
                    end
                end
            end
        end
    end

end
